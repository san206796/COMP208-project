//
//  ReminderModel.swift
//  Merseyside_bus
//
//  Created on 28/04/2025.
//

import Foundation
import FirebaseFirestore

/// Model representing a user reminder in the Merseyside bus app
struct Reminder: Codable {
    /// Unique identifier for the reminder
    var id: String
    
    /// Title/name of the reminder
    var title: String
    
    /// Date when the reminder is scheduled for
    var date: Date
    
    /// Time of day for the reminder
    var time: Date
    
    /// Optional additional notes for the reminder
    var notes: String?
    
    /// The user ID who owns this reminder
    var userId: String
    
    /// Creates a Dictionary representation for Firestore storage
    func toDictionary() -> [String: Any] {
        return [
            "id": id,
            "title": title,
            "date": Timestamp(date: date),
            "time": Timestamp(date: time),
            "notes": notes ?? "",
            "userId": userId
        ]
    }
    
    /// Creates a Reminder from a Firestore document
    static func fromDictionary(_ data: [String: Any], id: String) -> Reminder? {
        guard let title = data["title"] as? String,
              let dateTimestamp = data["date"] as? Timestamp,
              let timeTimestamp = data["time"] as? Timestamp,
              let userId = data["userId"] as? String else {
            return nil
        }
        
        return Reminder(
            id: id,
            title: title,
            date: dateTimestamp.dateValue(),
            time: timeTimestamp.dateValue(),
            notes: data["notes"] as? String,
            userId: userId
        )
    }
    
    /// Checks if the reminder is scheduled for today
    var isToday: Bool {
        let calendar = Calendar.current
        return calendar.isDateInToday(date)
    }
}