//
//  BusModels.swift
//  Merseyside_bus
//
//  Created by Shivansh Raj on 26/04/2025.
//

import Foundation

struct SuperBusData: Codable {
    let routes: [String: SuperRoute]
}

struct SuperRoute: Codable {
    let stops: [BusStop]
}

struct BusStop: Codable {
    let stop_name: String
    let times: [String]
}

