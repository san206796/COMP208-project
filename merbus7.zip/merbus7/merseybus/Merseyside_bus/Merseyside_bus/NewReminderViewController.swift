//
//  NewReminderViewController.swift
//  Merseyside_bus
//
//  Created on 28/04/2025.
//

import UIKit

/// Protocol for notifying when a reminder is created
protocol NewReminderDelegate: AnyObject {
    /// Called when a new reminder has been successfully created
    func didCreateReminder()
}

/// View controller for creating new reminders
class NewReminderViewController: UIViewController {
    
    // MARK: - UI Elements
    
    /// Container view for the form
    private let formContainerView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = .systemYellow
        view.layer.cornerRadius = 15
        return view
    }()
    
    /// Text field for the reminder title
    private let titleTextField: UITextField = {
        let textField = UITextField()
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.placeholder = "Title"
        textField.font = UIFont.systemFont(ofSize: 16)
        textField.borderStyle = .none
        textField.backgroundColor = .clear
        return textField
    }()
    
    /// Title separator line
    private let titleSeparator: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = .black
        view.alpha = 0.2
        return view
    }()
    
    /// Date picker for the reminder date
    private let datePicker: UIDatePicker = {
        let picker = UIDatePicker()
        picker.translatesAutoresizingMaskIntoConstraints = false
        picker.datePickerMode = .date
        if #available(iOS 14.0, *) {
            picker.preferredDatePickerStyle = .compact
        }
        return picker
    }()
    
    /// Label for the date field
    private let dateLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "Date"
        label.font = UIFont.systemFont(ofSize: 16)
        return label
    }()
    
    /// Date separator line
    private let dateSeparator: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = .black
        view.alpha = 0.2
        return view
    }()
    
    /// Time picker for the reminder time
    private let timePicker: UIDatePicker = {
        let picker = UIDatePicker()
        picker.translatesAutoresizingMaskIntoConstraints = false
        picker.datePickerMode = .time
        if #available(iOS 14.0, *) {
            picker.preferredDatePickerStyle = .compact
        }
        return picker
    }()
    
    /// Label for the time field
    private let timeLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "Time"
        label.font = UIFont.systemFont(ofSize: 16)
        return label
    }()
    
    /// Time separator line
    private let timeSeparator: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = .black
        view.alpha = 0.2
        return view
    }()
    
    /// Text view for reminder notes
    private let notesTextView: UITextView = {
        let textView = UITextView()
        textView.translatesAutoresizingMaskIntoConstraints = false
        textView.font = UIFont.systemFont(ofSize: 16)
        textView.backgroundColor = .clear
        textView.isScrollEnabled = true
        return textView
    }()
    
    /// Label for the notes field
    private let notesLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "Notes"
        label.font = UIFont.systemFont(ofSize: 16)
        return label
    }()
    
    /// Notes separator line
    private let notesSeparator: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.backgroundColor = .black
        view.alpha = 0.2
        return view
    }()
    
    /// Save button
    private let saveButton: UIButton = {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.backgroundColor = .systemYellow
        button.layer.cornerRadius = 15
        button.setTitle("Save", for: .normal)
        button.setTitleColor(.black, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 18, weight: .medium)
        button.addTarget(self, action: #selector(saveButtonTapped), for: .touchUpInside)
        return button
    }()
    
    // MARK: - Properties
    
    /// Delegate to notify when a reminder is created
    weak var delegate: NewReminderDelegate?
    
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemGray6
        setupUI()
        setupGestures()
    }
    
    // MARK: - UI Setup
    
    /// Sets up the user interface
    private func setupUI() {
        // Add subviews
        view.addSubview(formContainerView)
        formContainerView.addSubview(titleTextField)
        formContainerView.addSubview(titleSeparator)
        
        formContainerView.addSubview(dateLabel)
        formContainerView.addSubview(datePicker)
        formContainerView.addSubview(dateSeparator)
        
        formContainerView.addSubview(timeLabel)
        formContainerView.addSubview(timePicker)
        formContainerView.addSubview(timeSeparator)
        
        formContainerView.addSubview(notesLabel)
        formContainerView.addSubview(notesTextView)
        formContainerView.addSubview(notesSeparator)
        
        view.addSubview(saveButton)
        
        // Set up Auto Layout constraints
        NSLayoutConstraint.activate([
            // Form container
            formContainerView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            formContainerView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            formContainerView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            
            // Title field
            titleTextField.topAnchor.constraint(equalTo: formContainerView.topAnchor, constant: 20),
            titleTextField.leadingAnchor.constraint(equalTo: formContainerView.leadingAnchor, constant: 15),
            titleTextField.trailingAnchor.constraint(equalTo: formContainerView.trailingAnchor, constant: -15),
            titleTextField.heightAnchor.constraint(equalToConstant: 30),
            
            titleSeparator.topAnchor.constraint(equalTo: titleTextField.bottomAnchor, constant: 5),
            titleSeparator.leadingAnchor.constraint(equalTo: formContainerView.leadingAnchor, constant: 15),
            titleSeparator.trailingAnchor.constraint(equalTo: formContainerView.trailingAnchor, constant: -15),
            titleSeparator.heightAnchor.constraint(equalToConstant: 1),
            
            // Date field
            dateLabel.topAnchor.constraint(equalTo: titleSeparator.bottomAnchor, constant: 15),
            dateLabel.leadingAnchor.constraint(equalTo: formContainerView.leadingAnchor, constant: 15),
            
            datePicker.centerYAnchor.constraint(equalTo: dateLabel.centerYAnchor),
            datePicker.trailingAnchor.constraint(equalTo: formContainerView.trailingAnchor, constant: -15),
            
            dateSeparator.topAnchor.constraint(equalTo: dateLabel.bottomAnchor, constant: 10),
            dateSeparator.leadingAnchor.constraint(equalTo: formContainerView.leadingAnchor, constant: 15),
            dateSeparator.trailingAnchor.constraint(equalTo: formContainerView.trailingAnchor, constant: -15),
            dateSeparator.heightAnchor.constraint(equalToConstant: 1),
            
            // Time field
            timeLabel.topAnchor.constraint(equalTo: dateSeparator.bottomAnchor, constant: 15),
            timeLabel.leadingAnchor.constraint(equalTo: formContainerView.leadingAnchor, constant: 15),
            
            timePicker.centerYAnchor.constraint(equalTo: timeLabel.centerYAnchor),
            timePicker.trailingAnchor.constraint(equalTo: formContainerView.trailingAnchor, constant: -15),
            
            timeSeparator.topAnchor.constraint(equalTo: timeLabel.bottomAnchor, constant: 10),
            timeSeparator.leadingAnchor.constraint(equalTo: formContainerView.leadingAnchor, constant: 15),
            timeSeparator.trailingAnchor.constraint(equalTo: formContainerView.trailingAnchor, constant: -15),
            timeSeparator.heightAnchor.constraint(equalToConstant: 1),
            
            // Notes field
            notesLabel.topAnchor.constraint(equalTo: timeSeparator.bottomAnchor, constant: 15),
            notesLabel.leadingAnchor.constraint(equalTo: formContainerView.leadingAnchor, constant: 15),
            
            notesTextView.topAnchor.constraint(equalTo: notesLabel.bottomAnchor, constant: 5),
            notesTextView.leadingAnchor.constraint(equalTo: formContainerView.leadingAnchor, constant: 10),
            notesTextView.trailingAnchor.constraint(equalTo: formContainerView.trailingAnchor, constant: -10),
            notesTextView.heightAnchor.constraint(equalToConstant: 80),
            
            notesSeparator.topAnchor.constraint(equalTo: notesTextView.bottomAnchor, constant: 5),
            notesSeparator.leadingAnchor.constraint(equalTo: formContainerView.leadingAnchor, constant: 15),
            notesSeparator.trailingAnchor.constraint(equalTo: formContainerView.trailingAnchor, constant: -15),
            notesSeparator.heightAnchor.constraint(equalToConstant: 1),
            notesSeparator.bottomAnchor.constraint(equalTo: formContainerView.bottomAnchor, constant: -20),
            
            // Save button
            saveButton.topAnchor.constraint(equalTo: formContainerView.bottomAnchor, constant: 20),
            saveButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            saveButton.widthAnchor.constraint(equalTo: formContainerView.widthAnchor),
            saveButton.heightAnchor.constraint(equalToConstant: 50)
        ])
    }
    
    /// Sets up tap gesture recognizer to dismiss keyboard
    private func setupGestures() {
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        view.addGestureRecognizer(tapGesture)
    }
    
    // MARK: - Actions
    
    /// Dismisses the keyboard when tapping outside of text fields
    @objc private func dismissKeyboard() {
        view.endEditing(true)
    }
    
    /// Handles save button tap
    @objc private func saveButtonTapped() {
        guard let title = titleTextField.text, !title.isEmpty else {
            showAlert(message: "Please enter a title for the reminder")
            return
        }
        
        // Create a new reminder
        let reminder = Reminder(
            id: "",  // Empty ID will be replaced with a UUID in the service
            title: title,
            date: datePicker.date,
            time: timePicker.date,
            notes: notesTextView.text,
            userId: ""  // Empty userId will be replaced with the current user ID in the service
        )
        
        // Save to Firebase
        ReminderService.shared.saveReminder(reminder) { [weak self] result in
            guard let self = self else { return }
            
            switch result {
            case .success:
                DispatchQueue.main.async {
                    self.delegate?.didCreateReminder()
                    self.navigationController?.popViewController(animated: true)
                }
            case .failure(let error):
                print("Error saving reminder: \(error.localizedDescription)")
                DispatchQueue.main.async {
                    self.showAlert(message: "Failed to save reminder. Please try again.")
                }
            }
        }
    }
    
    // MARK: - Helper Methods
    
    /// Shows an alert with the given message
    private func showAlert(message: String) {
        let alert = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}