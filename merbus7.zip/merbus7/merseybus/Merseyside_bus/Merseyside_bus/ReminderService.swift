//
//  ReminderService.swift
//  Merseyside_bus
//
//  Created on 28/04/2025.
//

import Foundation
import FirebaseFirestore
import FirebaseAuth

/// Service class to handle reminder-related operations with Firebase
class ReminderService {
    /// Shared instance for singleton access pattern
    static let shared = ReminderService()
    
    /// Firestore database reference
    private let db = Firestore.firestore()
    
    /// Collection reference for reminders in Firestore
    private var remindersCollection: CollectionReference {
        return db.collection("reminders")
    }
    
    /// Current user ID from Firebase Authentication, if authenticated
    var currentUserId: String? {
        return Auth.auth().currentUser?.uid
    }
    
    /// Private initializer for singleton pattern
    private init() {}
    
    /// Saves a new reminder to Firebase
    /// - Parameters:
    ///   - reminder: The reminder to save
    ///   - completion: Callback with result of the operation
    func saveReminder(_ reminder: Reminder, completion: @escaping (Result<Reminder, Error>) -> Void) {
        guard let userId = currentUserId else {
            completion(.failure(NSError(domain: "ReminderService", code: 401, userInfo: [NSLocalizedDescriptionKey: "User not authenticated"])))
            return
        }
        
        var reminderToSave = reminder
        
        // If this is a new reminder without an ID, create one
        if reminder.id.isEmpty {
            reminderToSave.id = UUID().uuidString
        }
        
        reminderToSave.userId = userId
        
        remindersCollection.document(reminderToSave.id).setData(reminderToSave.toDictionary()) { error in
            if let error = error {
                completion(.failure(error))
            } else {
                completion(.success(reminderToSave))
            }
        }
    }
    
    /// Fetches all reminders for the current user
    /// - Parameter completion: Callback with the fetched reminders
    func fetchReminders(completion: @escaping (Result<[Reminder], Error>) -> Void) {
        guard let userId = currentUserId else {
            completion(.failure(NSError(domain: "ReminderService", code: 401, userInfo: [NSLocalizedDescriptionKey: "User not authenticated"])))
            return
        }
        
        remindersCollection.whereField("userId", isEqualTo: userId).getDocuments { snapshot, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            
            guard let documents = snapshot?.documents else {
                completion(.success([]))
                return
            }
            
            let reminders = documents.compactMap { document -> Reminder? in
                return Reminder.fromDictionary(document.data(), id: document.documentID)
            }
            
            completion(.success(reminders))
        }
    }
    
    /// Deletes a reminder from Firebase
    /// - Parameters:
    ///   - reminderId: ID of the reminder to delete
    ///   - completion: Callback with the result of the operation
    func deleteReminder(reminderId: String, completion: @escaping (Result<Void, Error>) -> Void) {
        remindersCollection.document(reminderId).delete { error in
            if let error = error {
                completion(.failure(error))
            } else {
                completion(.success(()))
            }
        }
    }
}