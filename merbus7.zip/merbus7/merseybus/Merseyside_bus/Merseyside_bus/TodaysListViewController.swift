//
//  TodaysListViewController.swift
//  Merseyside_bus
//
//  Created on 28/04/2025.
//

import UIKit

/// View controller for displaying today's reminders
class TodaysListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    // MARK: - UI Elements
    
    /// Table view to display today's reminders
    private let tableView: UITableView = {
        let tableView = UITableView()
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.backgroundColor = .clear
        tableView.separatorStyle = .none
        tableView.register(ReminderCell.self, forCellReuseIdentifier: "ReminderCell")
        return tableView
    }()
    
    /// Label shown when there are no reminders today
    private let noRemindersLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "No Reminders"
        label.font = UIFont.systemFont(ofSize: 18)
        label.textColor = .darkGray
        label.textAlignment = .center
        return label
    }()
    
    // MARK: - Properties
    
    /// Array of today's reminders to display
    var reminders: [Reminder] = []
    
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemGray6
        setupUI()
    }
    
    // MARK: - UI Setup
    
    /// Sets up the user interface
    private func setupUI() {
        // Configure table view
        tableView.delegate = self
        tableView.dataSource = self
        
        // Add subviews
        view.addSubview(tableView)
        view.addSubview(noRemindersLabel)
        
        // Set up Auto Layout constraints
        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor),
            
            noRemindersLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            noRemindersLabel.centerYAnchor.constraint(equalTo: view.centerYAnchor)
        ])
        
        updateUI()
    }
    
    /// Updates the UI based on whether there are reminders to display
    private func updateUI() {
        noRemindersLabel.isHidden = !reminders.isEmpty
        tableView.isHidden = reminders.isEmpty
        tableView.reloadData()
    }
    
    // MARK: - TableView DataSource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return reminders.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "ReminderCell", for: indexPath) as? ReminderCell else {
            return UITableViewCell()
        }
        
        let reminder = reminders[indexPath.row]
        cell.configure(with: reminder)
        return cell
    }
    
    // MARK: - TableView Delegate
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let deleteAction = UIContextualAction(style: .destructive, title: "Delete") { [weak self] (_, _, completion) in
            guard let self = self else { return }
            
            let reminder = self.reminders[indexPath.row]
            
            ReminderService.shared.deleteReminder(reminderId: reminder.id) { result in
                switch result {
                case .success:
                    // Update the UI
                    self.reminders.remove(at: indexPath.row)
                    DispatchQueue.main.async {
                        tableView.deleteRows(at: [indexPath], with: .automatic)
                        self.updateUI()
                    }
                case .failure(let error):
                    print("Error deleting reminder: \(error.localizedDescription)")
                    DispatchQueue.main.async {
                        self.showAlert(message: "Failed to delete reminder. Please try again.")
                    }
                }
            }
            
            completion(true)
        }
        
        return UISwipeActionsConfiguration(actions: [deleteAction])
    }
    
    // MARK: - Helper Methods
    
    /// Shows an alert with the given