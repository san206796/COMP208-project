//
//  MyScheduleViewController.swift
//  Merseyside_bus
//
//  Created on 28/04/2025.
//

import UIKit

/// Main view controller for the My Schedule feature
/// Shows options for viewing all reminders, today's reminders, and creating new reminders
class MyScheduleViewController: UIViewController {
    
    // MARK: - UI Elements
    
    /// Title label for the screen
    private let titleLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "My Schedule"
        label.font = UIFont.systemFont(ofSize: 32, weight: .bold)
        return label
    }()
    
    /// Button to view all reminders
    private let myRemindersButton: UIButton = {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.backgroundColor = .systemYellow
        button.layer.cornerRadius = 15
        button.contentHorizontalAlignment = .left
        button.titleEdgeInsets = UIEdgeInsets(top: 0, left: 15, bottom: 0, right: 0)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 18, weight: .medium)
        button.setTitleColor(.black, for: .normal)
        button.addTarget(self, action: #selector(openMyReminders), for: .touchUpInside)
        return button
    }()
    
    /// Button to view today's reminders
    private let todaysListButton: UIButton = {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.backgroundColor = .systemYellow
        button.layer.cornerRadius = 15
        button.contentHorizontalAlignment = .left
        button.titleEdgeInsets = UIEdgeInsets(top: 0, left: 15, bottom: 0, right: 0)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 18, weight: .medium)
        button.setTitleColor(.black, for: .normal)
        button.addTarget(self, action: #selector(openTodaysList), for: .touchUpInside)
        return button
    }()
    
    /// Button to create a new reminder
    private let newReminderButton: UIButton = {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.backgroundColor = .systemYellow
        button.layer.cornerRadius = 15
        button.contentHorizontalAlignment = .left
        button.titleEdgeInsets = UIEdgeInsets(top: 0, left: 15, bottom: 0, right: 0)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 18, weight: .medium)
        button.setTitleColor(.black, for: .normal)
        button.addTarget(self, action: #selector(openNewReminder), for: .touchUpInside)
        return button
    }()
    
    /// Label showing count of reminders for My Reminders
    private let myRemindersCountLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "0"
        label.font = UIFont.systemFont(ofSize: 18, weight: .medium)
        label.textAlignment = .right
        return label
    }()
    
    /// Label showing count of reminders for Today's List
    private let todaysListCountLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "0"
        label.font = UIFont.systemFont(ofSize: 18, weight: .medium)
        label.textAlignment = .right
        return label
    }()
    
    /// Plus icon for the New Reminder button
    private let plusIconImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.image = UIImage(systemName: "plus.circle")
        imageView.contentMode = .scaleAspectFit
        imageView.tintColor = .black
        return imageView
    }()
    
    // MARK: - Properties
    
    /// Array of all reminders
    private var reminders: [Reminder] = []
    
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemGray6 // Light gray background
        setupUI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        loadReminders()
    }
    
    // MARK: - UI Setup
    
    /// Sets up the user interface
    private func setupUI() {
        // Add subviews
        view.addSubview(titleLabel)
        view.addSubview(myRemindersButton)
        view.addSubview(todaysListButton)
        view.addSubview(newReminderButton)
        view.addSubview(myRemindersCountLabel)
        view.addSubview(todaysListCountLabel)
        view.addSubview(plusIconImageView)
        
        // Set button titles
        myRemindersButton.setTitle("My Reminders", for: .normal)
        todaysListButton.setTitle("Today's List", for: .normal)
        newReminderButton.setTitle("New Reminder", for: .normal)
        
        // Set up Auto Layout constraints
        NSLayoutConstraint.activate([
            // Title label
            titleLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            titleLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            titleLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            
            // My Reminders Button
            myRemindersButton.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 30),
            myRemindersButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            myRemindersButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            myRemindersButton.heightAnchor.constraint(equalToConstant: 50),
            
            // My Reminders Count Label
            myRemindersCountLabel.centerYAnchor.constraint(equalTo: myRemindersButton.centerYAnchor),
            myRemindersCountLabel.trailingAnchor.constraint(equalTo: myRemindersButton.trailingAnchor, constant: -15),
            myRemindersCountLabel.widthAnchor.constraint(equalToConstant: 40),
            
            // Today's List Button
            todaysListButton.topAnchor.constraint(equalTo: myRemindersButton.bottomAnchor, constant: 20),
            todaysListButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            todaysListButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            todaysListButton.heightAnchor.constraint(equalToConstant: 50),
            
            // Today's List Count Label
            todaysListCountLabel.centerYAnchor.constraint(equalTo: todaysListButton.centerYAnchor),
            todaysListCountLabel.trailingAnchor.constraint(equalTo: todaysListButton.trailingAnchor, constant: -15),
            todaysListCountLabel.widthAnchor.constraint(equalToConstant: 40),
            
            // New Reminder Button
            newReminderButton.topAnchor.constraint(equalTo: todaysListButton.bottomAnchor, constant: 20),
            newReminderButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            newReminderButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            newReminderButton.heightAnchor.constraint(equalToConstant: 50),
            
            // Plus Icon
            plusIconImageView.centerYAnchor.constraint(equalTo: newReminderButton.centerYAnchor),
            plusIconImageView.trailingAnchor.constraint(equalTo: newReminderButton.trailingAnchor, constant: -15),
            plusIconImageView.widthAnchor.constraint(equalToConstant: 24),
            plusIconImageView.heightAnchor.constraint(equalToConstant: 24)
        ])
    }
    
    // MARK: - Data Loading
    
    /// Loads reminders from Firebase
    private func loadReminders() {
        ReminderService.shared.fetchReminders { [weak self] result in
            guard let self = self else { return }
            
            switch result {
            case .success(let reminders):
                self.reminders = reminders
                self.updateUI()
            case .failure(let error):
                print("Error fetching reminders: \(error.localizedDescription)")
                self.showAlert(message: "Failed to load reminders. Please try again.")
            }
        }
    }
    
    /// Updates the UI with current reminder counts
    private func updateUI() {
        let totalCount = reminders.count
        let todayCount = reminders.filter { $0.isToday }.count
        
        DispatchQueue.main.async {
            self.myRemindersCountLabel.text = "\(totalCount)"
            self.todaysListCountLabel.text = "\(todayCount)"
        }
    }
    
    // MARK: - Navigation Actions
    
    /// Opens the My Reminders screen
    @objc private func openMyReminders() {
        let remindersVC = MyRemindersViewController()
        remindersVC.title = "My Reminders"
        remindersVC.reminders = reminders
        navigationController?.pushViewController(remindersVC, animated: true)
    }
    
    /// Opens the Today's List screen
    @objc private func openTodaysList() {
        let todayVC = TodaysListViewController()
        todayVC.title = "Today's List"
        todayVC.reminders = reminders.filter { $0.isToday }
        navigationController?.pushViewController(todayVC, animated: true)
    }
    
    /// Opens the New Reminder screen
    @objc private func openNewReminder() {
        let newReminderVC = NewReminderViewController()
        newReminderVC.title = "New Reminder"
        newReminderVC.delegate = self
        navigationController?.pushViewController(newReminderVC, animated: true)
    }
    
    // MARK: - Helper Methods
    
    /// Shows an alert with the given message
    private func showAlert(message: String) {
        let alert = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}

// MARK: - NewReminderDelegate

extension MyScheduleViewController: NewReminderDelegate {
    /// Callback when a new reminder is created
    func didCreateReminder() {
        loadReminders()
    }
}