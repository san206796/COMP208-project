//
//  SignInViewController.swift
//  Merseyside_bus
//
//  Created by Shivansh Raj on 28/04/2025.
//

// Import required frameworks
import UIKit                // Core iOS UI framework
import Firebase             // Firebase core functionality
import FirebaseAuth         // Firebase authentication services
import FirebaseFirestore    // Firebase Cloud Firestore database

/**
 * View controller responsible for handling existing user sign-in functionality
 * 
 * This controller verifies user credentials against Firebase Authentication and
 * redirects to the main menu upon successful authentication
 */
class SignInViewController: UIViewController {
    
    // MARK: - Outlets
    
    /// Text field for user to enter their email address
    @IBOutlet weak var emailTextField: UITextField!
    
    /// Text field for user to enter their password
    @IBOutlet weak var passwordTextField: UITextField!
    
    /// Button that triggers the sign-in process
    @IBOutlet weak var signInButton: UIButton!
    
    /// Label to display error messages to the user
    @IBOutlet weak var errorLabel: UILabel!
    
    // MARK: - Lifecycle Methods
    
    /**
     * Called when the view is loaded into memory
     * Performs initial setup of the UI elements
     */
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Initialize UI components
        setupUI()
    }
    
    // MARK: - UI Setup
    
    /**
     * Configures the initial state of UI elements
     * Sets properties like placeholder text, keyboard type, and security settings
     */
    private func setupUI() {
        // Hide error label initially - will only be shown when an error occurs
        errorLabel.isHidden = true
        
        // Configure email text field for best user experience
        emailTextField.placeholder = "Email"
        emailTextField.keyboardType = .emailAddress       // Shows email-optimized keyboard
        emailTextField.autocapitalizationType = .none     // Prevents auto-capitalization
        emailTextField.autocorrectionType = .no           // Disables autocorrection
        
        // Configure password text field
        passwordTextField.placeholder = "Password"
        passwordTextField.isSecureTextEntry = true        // Hides password text as dots
    }
    
    // MARK: - Actions
    
    /**
     * Handler for the sign-in button tap
     * Validates user inputs and attempts to authenticate with Firebase
     *
     * @param sender The UI element that triggered this action
     */
    @IBAction func signInButtonTapped(_ sender: Any) {
        // Validate that both email and password fields are filled
        guard let email = emailTextField.text, !email.isEmpty,
              let password = passwordTextField.text, !password.isEmpty else {
            showError("Please enter both email and password")
            return
        }
        
        // You could add a loading indicator here (commented out as it needs to be added to storyboard)
        // activityIndicator.startAnimating()
        
        // Check if the user exists in Firestore first
        checkUserInFirestore(email: email) { [weak self] exists in
            // If the user doesn't exist in the database
            if !exists {
                self?.showError("No account found with this email")
                return
            }
            
            // User exists in Firestore, now authenticate with Firebase Auth
            self?.authenticateUser(email: email, password: password)
        }
    }
    
    /**
     * Authenticates user with Firebase Auth
     * Called after confirming the user exists in Firestore
     * 
     * @param email User's email address
     * @param password User's password
     */
    private func authenticateUser(email: String, password: String) {
        // Attempt to sign in using Firebase Authentication
        Auth.auth().signIn(withEmail: email, password: password) { [weak self] authResult, error in
            // Hide loading indicator when authentication completes (whether success or failure)
            // self?.activityIndicator.stopAnimating()
            
            if let error = error {
                // Authentication failed - show error message to the user
                self?.showError("Sign in failed: \(error.localizedDescription)")
                return
            }
            
            // Authentication successful - log and proceed
            print("User signed in successfully: \(authResult?.user.email ?? "")")
            
            // Navigate to the menu screen
            self?.performSegue(withIdentifier: "signInToMenu", sender: nil)
        }
    }
    
    /**
     * Displays an error message to the user
     * Shows the error label with the specified message and hides it after a delay
     *
     * @param message The error message to display to the user
     */
    private func showError(_ message: String) {
        // Set the error message text
        errorLabel.text = message
        // Make the error label visible
        errorLabel.isHidden = false
        
        // Automatically hide the error message after 3 seconds for better UX
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
            self.errorLabel.isHidden = true
        }
    }
    
    /**
     * Checks if the user exists in Firestore database
     * This provides more specific error messages to the user about whether their account exists
     *
     * @param email The email address to check
     * @param completion Closure that returns true if user exists, false otherwise
     */
    private func checkUserInFirestore(email: String, completion: @escaping (Bool) -> Void) {
        // Get reference to Firestore database
        let db = Firestore.firestore()
        
        // Query the users collection for documents with matching email
        db.collection("users").whereField("email", isEqualTo: email).getDocuments { snapshot, error in
            // Handle any Firestore query errors
            if let error = error {
                print("Error checking user: \(error.localizedDescription)")
                completion(false) // Assume user doesn't exist if there's an error
                return
            }
            
            // Check if any matching documents were found
            guard let documents = snapshot?.documents, !documents.isEmpty else {
                // No user found with this email
                completion(false)
                return
            }
            
            // User exists in Firestore
            completion(true)
        }
    }
    
    /**
     * Handler for the back button tap
     * Dismisses this view controller and returns to the previous screen
     *
     * @param sender The UI element that triggered this action
     */
    @IBAction func backButtonTapped(_ sender: Any) {
        // Dismiss this view controller with animation
        dismiss(animated: true, completion: nil)
    }
}