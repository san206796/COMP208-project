//
//  ViewController.swift
//  Merseyside_bus
//
//  Created by Shivansh Raj on 30/03/2025.
//

// Import required frameworks
import UIKit            // Core iOS UI framework
import Firebase         // Firebase core functionality
import FirebaseAuth     // Firebase authentication
import FirebaseFirestore // Firestore database
import GoogleSignIn     // Google Sign-In SDK

class ViewController: UIViewController {
    
    // MARK: - Outlets
    @IBOutlet weak var headingLabel: UILabel!     // Main heading of the welcome screen
    @IBOutlet weak var accountLabel: UILabel!     // Label for account information
    @IBOutlet weak var emailLabel: UILabel!       // Label for email field
    @IBOutlet weak var emailTextField: UITextField!  // Text field for user email input
    @IBOutlet weak var passwordTextField: UITextField! // Text field for user password input
    @IBOutlet weak var errorLabel: UILabel!       // Label to display error messages
    
    // MARK: - Actions
    
    /**
     * Handler for the create account button (previously continue button)
     * Creates a new user in Firebase Auth and Firestore using email and password
     * Checks if account already exists before attempting creation
     */
    @IBAction func createAccountButtonTapped(_ sender: Any) {
        // Validate that email and password fields are not empty
        guard let email = emailTextField.text, !email.isEmpty,
              let password = passwordTextField.text, !password.isEmpty else {
            showError("Please enter both email and password")
            return
        }
        
        // Ensure password meets minimum requirements
        if password.count < 6 {
            showError("Password must be at least 6 characters")
            return
        }
        
        // Extract username from email (everything before @)
        // This will be used as the display name for the account
        let username = email.components(separatedBy: "@").first ?? ""
        
        // First check if user already exists in Firebase Authentication
        checkIfUserExistsInFirebase(email: email) { [weak self] exists in
            if exists {
                // User already exists - show error message
                self?.showError("An account with this email already exists")
                return
            }
            
            // Create user in Firebase Authentication
            Auth.auth().createUser(withEmail: email, password: password) { authResult, error in
                if let error = error {
                    // Handle account creation error
                    self?.showError("Account creation failed: \(error.localizedDescription)")
                    return
                }
                
                guard let user = authResult?.user else {
                    self?.showError("Failed to create account")
                    return
                }
                
                // Successfully created user in Auth, now save to Firestore
                self?.saveNewUserToFirestore(user: user, username: username)
            }
        }
    }
    
    /**
     * Handler for the sign in button
     * Navigates to the SignInViewController for existing users to log in
     */
    @IBAction func signInButtonTapped(_ sender: Any) {
        // Navigate to SignInViewController using the toSignIn segue
        performSegue(withIdentifier: "toSignIn", sender: nil)
    }
    
    /**
     * Handler for Google Sign-In button
     * Initiates the Google authentication flow and saves user to Firestore upon success
     */
    @IBAction func googleSignInButtonTapped(_ sender: Any) {
        // Get the client ID from Firebase configuration
        guard let clientID = FirebaseApp.app()?.options.clientID else { return }
        
        // Configure Google Sign-In with the Firebase client ID
        let config = GIDConfiguration(clientID: clientID)
        GIDSignIn.sharedInstance.configuration = config
        
        // Get the top view controller to present the Google Sign-In UI
        guard let presentingVC = self.getTopViewController() else {
            print("Error: Unable to get root view controller")
            return
        }
        
        // Start Google Sign-In flow
        GIDSignIn.sharedInstance.signIn(withPresenting: presentingVC) { result, error in
            // Handle any errors from Google Sign-In
            if let error = error {
                print("Google Sign-In failed: \(error.localizedDescription)")
                return
            }
            
            // Extract user and token information from Google Sign-In result
            guard let user = result?.user,
                  let idToken = user.idToken?.tokenString else {
                print("Missing user or ID token")
                return
            }
            
            // Get access token needed for Firebase authentication
            let accessToken = user.accessToken.tokenString
            // Create Firebase credential using Google tokens
            let credential = GoogleAuthProvider.credential(withIDToken: idToken, accessToken: accessToken)
            
            // Authenticate with Firebase using Google credential
            Auth.auth().signIn(with: credential) { authResult, error in
                // Handle any Firebase authentication errors
                if let error = error {
                    print("Firebase Sign-In failed: \(error.localizedDescription)")
                    return
                }
                
                print("Firebase Sign-In Success! User: \(authResult?.user.email ?? "No Email")")
                
                // Save authenticated user to Firestore
                if let user = authResult?.user {
                    self.saveUserToFirestore(user: user)
                }
                
                // Navigate to the menu screen
                self.performSegue(withIdentifier: "toMenu", sender: nil)
            }
        }
    }
    
    // MARK: - Lifecycle Methods
    
    /**
     * View lifecycle method - called when the view is loaded into memory
     */
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Initialize UI elements
        setupUI()
    }
    
    // MARK: - UI Setup and Helper Methods
    
    /**
     * Configures initial UI state
     */
    private func setupUI() {
        // Configure password field
        passwordTextField.isSecureTextEntry = true
        passwordTextField.placeholder = "Password"
        
        // Hide error label initially
        errorLabel.isHidden = true
    }
    
    /**
     * Helper method to show error messages to the user
     * @param message The error message to display
     */
    private func showError(_ message: String) {
        errorLabel.text = message
        errorLabel.isHidden = false
        
        // Automatically hide the error message after 3 seconds
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
            self.errorLabel.isHidden = true
        }
    }
    
    /**
     * Check if a user with the given email already exists in Firestore
     * This is a secondary check to ensure data consistency
     * 
     * @param email The email to check
     * @param completion Handler with boolean result (true if user exists)
     */
    private func checkIfUserExistsInFirestore(email: String, completion: @escaping (Bool) -> Void) {
        let db = Firestore.firestore()
        
        // Query Firestore for any document with matching email
        db.collection("users").whereField("email", isEqualTo: email).getDocuments { snapshot, error in
            if let error = error {
                print("Error checking for existing user in Firestore: \(error.localizedDescription)")
                completion(false) // Assume user doesn't exist if there's an error
                return
            }
            
            // If there are any documents in the result, the user exists
            if let documents = snapshot?.documents, !documents.isEmpty {
                completion(true)
                return
            }
            
            // No documents found, user doesn't exist in Firestore
            completion(false)
        }
    }
    
    /**
     * Utility method to get the topmost view controller in the app
     * 
     * This is needed for presenting the Google Sign-In UI properly
     *
     * @return The topmost UIViewController in the view hierarchy, or nil if not found
     */
    func getTopViewController() -> UIViewController? {
        // Get the key window from the current scene
        guard let window = UIApplication.shared.connectedScenes
                .compactMap({ $0 as? UIWindowScene })  // Get UIWindowScene objects
                .first?.windows                        // Get windows of first scene
                .first(where: { $0.isKeyWindow }) else {  // Find key window
            return nil
        }
        
        // Find the top controller by traversing the view hierarchy
        var topController = window.rootViewController
        while let presentedViewController = topController?.presentedViewController {
            topController = presentedViewController
        }
        return topController
    }
}