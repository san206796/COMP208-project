//
//  MenuViewController.swift
//  Merseyside_bus
//
//  Created by Shivansh Raj on 30/03/2025.
//

//
//  MenuViewController.swift
//  Merseyside_bus
//
//  Created by Shivansh Raj on 30/03/2025.
//

import UIKit

class MenuViewController: UIViewController {

    // MARK: - Outlets
    @IBOutlet weak var startJourneyButton: UIButton!
    @IBOutlet weak var myInfoButton: UIButton!
    @IBOutlet weak var myScheduleButton: UIButton!
    @IBOutlet weak var contactlessButton: UIButton!
    @IBOutlet weak var topUpButton: UIButton!
    @IBOutlet weak var contactUsButton: UIButton!
    
    // MARK: - Actions
    @IBAction func startJourneyButton(_ sender: Any) {
        performSegue(withIdentifier: "toMap", sender: nil)
    }
    
    @IBAction func myInfoButton(_ sender: Any) {
        // Handle MY INFO button tap
        // Add implementation or navigation as needed
    }
    
    @IBAction func myScheduleButton(_ sender: Any) {
        // Handle MY SCHEDULE button tap
        // Add implementation or navigation as needed
    }
    
    @IBAction func topUpButton(_ sender: Any) {
        // Handle TOP-UP button tap
        // Add implementation or navigation as needed
    }
    
    @IBAction func contactlessButton(_ sender: Any) {
        performSegue(withIdentifier: "toBusCard", sender: nil)
    }
    
    @IBAction func contactUsButton(_ sender: Any) {
        performSegue(withIdentifier: "toContactUs", sender: nil)
    }
    
    // MARK: - View Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    // MARK: - UI Setup
    private func setupUI() {
        // Set up the appearance of all buttons
        setupButton(startJourneyButton, title: "START MY JOURNEY")
        setupButton(myInfoButton, title: "MY INFO")
        setupButton(myScheduleButton, title: "MY SCHEDULE")
        setupButton(contactlessButton, title: "CONTACTLESS")
        setupButton(topUpButton, title: "TOP-UP")
        setupButton(contactUsButton, title: "CONTACT US")
    }
    
    private func setupButton(_ button: UIButton, title: String) {
        // Set button appearance to match the design in the image
        button.setTitle(title, for: .normal)
        button.backgroundColor = UIColor.systemYellow
        button.setTitleColor(UIColor.black, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        button.layer.cornerRadius = 8
    }

    // MARK: - Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Handle preparation for segues if needed
        if segue.identifier == "toContactUs" {
            // If you need to pass any data to ContactUsViewController, do it here
        }
    }
}
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
