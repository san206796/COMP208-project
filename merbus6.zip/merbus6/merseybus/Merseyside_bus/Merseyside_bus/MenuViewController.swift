//
//  MenuViewController.swift
//  Merseyside_bus
//
//  Created by Shivansh Raj on 30/03/2025.
//

import UIKit

/// Main menu controller that serves as the central hub for app navigation
/// Displays buttons for all main features of the Merseyside bus app
class MenuViewController: UIViewController {

    // MARK: - Outlets
    /// Button to navigate to journey planning
    @IBOutlet weak var startJourneyButton: UIButton!
    
    /// Button to navigate to user profile/info screen
    @IBOutlet weak var myInfoButton: UIButton!
    
    /// Button to navigate to user's schedule/timetable
    @IBOutlet weak var myScheduleButton: UIButton!
    
    /// Button to navigate to contactless payment card
    @IBOutlet weak var contactlessButton: UIButton!
    
    /// Button to navigate to account top-up screen
    @IBOutlet weak var topUpButton: UIButton!
    
    /// Button to navigate to contact information
    @IBOutlet weak var contactUsButton: UIButton!
    
    // MARK: - Actions
    
    /// Handles tap on START MY JOURNEY button
    /// Navigates to the map/journey planner screen
    @IBAction func startJourneyButton(_ sender: Any) {
        performSegue(withIdentifier: "toMap", sender: nil)
    }
    
    /// Handles tap on MY INFO button
    /// Navigates to the user profile information screen
    @IBAction func myInfoButton(_ sender: Any) {
        performSegue(withIdentifier: "toMyInfo", sender: nil)
    }
    
    /// Handles tap on MY SCHEDULE button
    /// Will navigate to schedule/timetable screen when implemented
    @IBAction func myScheduleButton(_ sender: Any) {
        // Handle MY SCHEDULE button tap
        // Add implementation or navigation as needed
    }
    
    /// Handles tap on TOP-UP button
    /// Will navigate to account balance/payment screen when implemented
    @IBAction func topUpButton(_ sender: Any) {
        // Handle TOP-UP button tap
        // Add implementation or navigation as needed
    }
    
    /// Handles tap on CONTACTLESS button
    /// Navigates to the bus card display screen
    @IBAction func contactlessButton(_ sender: Any) {
        performSegue(withIdentifier: "toBusCard", sender: nil)
    }
    
    /// Handles tap on CONTACT US button
    /// Navigates to the contact information screen
    @IBAction func contactUsButton(_ sender: Any) {
        performSegue(withIdentifier: "toContactUs", sender: nil)
    }
    
    // MARK: - View Lifecycle
    
    /// Initial setup when the view loads
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    // MARK: - UI Setup
    
    /// Configures the appearance of all buttons and UI elements
    private func setupUI() {
        // Configure navigation bar
        self.navigationItem.title = "Menu"
        self.navigationItem.hidesBackButton = true
        
        // Set up the appearance of all buttons to match the yellow design
        setupButton(startJourneyButton, title: "START MY JOURNEY")
        setupButton(myInfoButton, title: "MY INFO")
        setupButton(myScheduleButton, title: "MY SCHEDULE")
        setupButton(contactlessButton, title: "CONTACTLESS")
        setupButton(topUpButton, title: "TOP-UP")
        setupButton(contactUsButton, title: "CONTACT US")
    }
    
    /// Helper method to apply consistent styling to all menu buttons
    /// @param button The button to style
    /// @param title The text to display on the button
    private func setupButton(_ button: UIButton, title: String) {
        // Set button appearance to match the design in the image
        button.setTitle(title, for: .normal)
        button.backgroundColor = UIColor.systemYellow
        button.setTitleColor(UIColor.black, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        button.layer.cornerRadius = 8
        
        // Add shadow for depth (optional)
        button.layer.shadowColor = UIColor.black.cgColor
        button.layer.shadowOffset = CGSize(width: 0, height: 2)
        button.layer.shadowRadius = 4
        button.layer.shadowOpacity = 0.1
    }

    // MARK: - Navigation
    
    /// Prepares for navigation to other screens
    /// Called before the segue is performed
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Handle preparation for different segues
        switch segue.identifier {
        case "toContactUs":
            // If you need to pass any data to ContactUsViewController, do it here
            break
            
        case "toMyInfo":
            // If you need to pass any data to MyInfoViewController, do it here
            break
            
        case "toMap":
            // If you need to pass any data to MapViewController, do it here
            break
            
        case "toBusCard":
            // If you need to pass any data to BusCardViewController, do it here
            break
            
        default:
            break
        }
    }
}