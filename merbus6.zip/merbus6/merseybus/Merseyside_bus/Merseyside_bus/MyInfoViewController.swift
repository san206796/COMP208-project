//
//  MyInfoViewController.swift
//  Merseyside_bus
//
//  Created on 27/04/2025.
//

import UIKit

/// View controller that displays the user's personal and card information
/// Shows details like name, email, phone, card ID, and subscription status
class MyInfoViewController: UIViewController {
    
    // MARK: - UI Elements
    
    /// Main title label displaying "My Info" at the top of the screen
    private let titleLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "My Info"
        label.font = UIFont.systemFont(ofSize: 32, weight: .bold)
        return label
    }()
    
    /// Arrays to store the UI elements for dynamic creation and layout
    private var fieldLabels: [UILabel] = []    // Labels on the left (Name:, Email:, etc.)
    private var fieldValues: [UILabel] = []    // Values on the right (user data)
    private var separatorLines: [UIView] = []  // Horizontal lines between rows
    
    /// Field names to display on the left side
    private let fields = [
        "Name:", "Email Id:", "Phone:", "Card Id :", "Card Status:", "Valid Until:", "Ticket:"
    ]
    
    /// Field values to display on the right side (would typically come from a user profile)
    private let values = [
        "Mer Bus", "MerBus@yyy.com", "+44 0720xxxxxx", ".... 1234", "Active", "30/5/2025", "Adult 4 -Weekly"
    ]
    
    // MARK: - View Lifecycle
    
    /// Initial setup when the view loads
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemGray6  // Light gray background to match iOS settings style
        setupUI()
    }
    
    // MARK: - UI Setup
    
    /// Main method to set up the user interface
    private func setupUI() {
        // Add the title label to the view
        view.addSubview(titleLabel)
        
        // Configure constraints for the title label
        NSLayoutConstraint.activate([
            titleLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            titleLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            titleLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20)
        ])
        
        // Set up the information field rows
        setupInfoFields()
    }
    
    /// Creates and lays out all the information fields (labels, values, and separator lines)
    private func setupInfoFields() {
        // Loop through each field and create the corresponding UI elements
        for i in 0..<fields.count {
            // Create field label (left side - field name)
            let fieldLabel = UILabel()
            fieldLabel.translatesAutoresizingMaskIntoConstraints = false
            fieldLabel.text = fields[i]
            fieldLabel.font = UIFont.systemFont(ofSize: 16)
            view.addSubview(fieldLabel)
            fieldLabels.append(fieldLabel)
            
            // Create value label (right side - user data)
            let valueLabel = UILabel()
            valueLabel.translatesAutoresizingMaskIntoConstraints = false
            valueLabel.text = values[i]
            valueLabel.font = UIFont.systemFont(ofSize: 16)
            valueLabel.textAlignment = .right  // Right-aligned to match design
            view.addSubview(valueLabel)
            fieldValues.append(valueLabel)
            
            // Create separator line below each row
            let separatorLine = UIView()
            separatorLine.translatesAutoresizingMaskIntoConstraints = false
            separatorLine.backgroundColor = .systemGray3  // Light gray line
            view.addSubview(separatorLine)
            separatorLines.append(separatorLine)
        }
        
        // Set up Auto Layout constraints for all elements
        for i in 0..<fields.count {
            let fieldLabel = fieldLabels[i]
            let valueLabel = fieldValues[i]
            let separatorLine = separatorLines[i]
            
            NSLayoutConstraint.activate([
                // Field label constraints - fixed width on left side
                fieldLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
                fieldLabel.widthAnchor.constraint(equalToConstant: 100),
                
                // Value label constraints - flexible width on right side
                valueLabel.leadingAnchor.constraint(equalTo: fieldLabel.trailingAnchor, constant: 8),
                valueLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
                
                // Align field and value labels vertically
                fieldLabel.centerYAnchor.constraint(equalTo: valueLabel.centerYAnchor),
                
                // Separator line constraints - full width with margins
                separatorLine.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
                separatorLine.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
                separatorLine.heightAnchor.constraint(equalToConstant: 1),  // 1px thin line
                separatorLine.topAnchor.constraint(equalTo: fieldLabel.bottomAnchor, constant: 15)
            ])
            
            // Position the rows vertically:
            // - First row positioned relative to the title
            // - Subsequent rows positioned relative to the previous separator line
            if i == 0 {
                fieldLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 40).isActive = true
            } else {
                fieldLabel.topAnchor.constraint(equalTo: separatorLines[i-1].bottomAnchor, constant: 15).isActive = true
            }
        }
    }
    
    // MARK: - Data Management
    
    // In a real app, you would have methods here to:
    // - Fetch user profile data from Core Data or a server
    // - Update the UI with the fetched data
    // - Handle any potential refresh or update mechanisms
}