//
//  ContactUsViewController.swift
//  Merseyside_bus
//
//  Created on 27/04/2025.
//

import UIKit

/// View controller that displays contact information for the Merseyside bus service
class ContactUsViewController: UIViewController {
    
    // MARK: - UI Elements
    
    /// Main title label displaying "Contact Us"
    private let titleLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "Contact Us"
        label.font = UIFont.systemFont(ofSize: 32, weight: .bold)
        return label
    }()
    
    /// Descriptive text explaining when to contact customer service
    private let descriptionLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "Don't hesitate to contact us whether you have a suggestion on our improvement, a complain to discuss or an issue to solve."
        label.textColor = .gray
        label.font = UIFont.systemFont(ofSize: 16)
        label.numberOfLines = 0 // Allows multiple lines of text
        return label
    }()
    
    /// Button with phone icon for visual display
    private let callButton: UIButton = {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.backgroundColor = .black
        button.layer.cornerRadius = 10
        
        // Phone icon
        let phoneImage = UIImage(systemName: "phone.fill")
        button.setImage(phoneImage, for: .normal)
        button.tintColor = .white
        
        return button
    }()
    
    /// Label displaying "Call us" text beneath the call button
    private let callLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "Call us"
        label.textAlignment = .center
        label.font = UIFont.systemFont(ofSize: 14)
        return label
    }()
    
    /// Label showing the phone number to call
    private let phoneLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "07xxxxxxxxx"
        label.textAlignment = .center
        label.font = UIFont.systemFont(ofSize: 14)
        return label
    }()
    
    /// Button with email icon for visual display
    private let emailButton: UIButton = {
        let button = UIButton()
        button.translatesAutoresizingMaskIntoConstraints = false
        button.backgroundColor = .black
        button.layer.cornerRadius = 10
        
        // Email icon
        let emailImage = UIImage(systemName: "envelope.fill")
        button.setImage(emailImage, for: .normal)
        button.tintColor = .white
        
        return button
    }()
    
    /// Label displaying "Email us" text beneath the email button
    private let emailLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "Email us"
        label.textAlignment = .center
        label.font = UIFont.systemFont(ofSize: 14)
        return label
    }()
    
    /// Label showing the email address to contact
    private let emailAddressLabel: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.text = "merbus@xxx.com"
        label.textAlignment = .center
        label.font = UIFont.systemFont(ofSize: 14)
        return label
    }()
    
    // MARK: - View Lifecycle
    
    /// Initial setup when the view loads
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemGray6 // Light gray background like in the image
        setupUI()
    }
    
    // MARK: - UI Setup
    
    /// Configures and arranges all UI elements on the screen
    private func setupUI() {
        // Add all UI elements to the view hierarchy
        view.addSubview(titleLabel)
        view.addSubview(descriptionLabel)
        
        view.addSubview(callButton)
        view.addSubview(callLabel)
        view.addSubview(phoneLabel)
        
        view.addSubview(emailButton)
        view.addSubview(emailLabel)
        view.addSubview(emailAddressLabel)
        
        // Set up Auto Layout constraints to position UI elements
        NSLayoutConstraint.activate([
            // Title label constraints - positioned at the top with margin
            titleLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            titleLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            titleLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            
            // Description label constraints - positioned below title
            descriptionLabel.topAnchor.constraint(equalTo: titleLabel.bottomAnchor, constant: 16),
            descriptionLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            descriptionLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            
            // Call button and related labels - positioned on the left side
            callButton.topAnchor.constraint(equalTo: descriptionLabel.bottomAnchor, constant: 40),
            callButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 80),
            callButton.widthAnchor.constraint(equalToConstant: 60),
            callButton.heightAnchor.constraint(equalToConstant: 60),
            
            callLabel.topAnchor.constraint(equalTo: callButton.bottomAnchor, constant: 8),
            callLabel.centerXAnchor.constraint(equalTo: callButton.centerXAnchor),
            
            phoneLabel.topAnchor.constraint(equalTo: callLabel.bottomAnchor, constant: 4),
            phoneLabel.centerXAnchor.constraint(equalTo: callButton.centerXAnchor),
            
            // Email button and related labels - positioned on the right side
            emailButton.topAnchor.constraint(equalTo: descriptionLabel.bottomAnchor, constant: 40),
            emailButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -80),
            emailButton.widthAnchor.constraint(equalToConstant: 60),
            emailButton.heightAnchor.constraint(equalToConstant: 60),
            
            emailLabel.topAnchor.constraint(equalTo: emailButton.bottomAnchor, constant: 8),
            emailLabel.centerXAnchor.constraint(equalTo: emailButton.centerXAnchor),
            
            emailAddressLabel.topAnchor.constraint(equalTo: emailLabel.bottomAnchor, constant: 4),
            emailAddressLabel.centerXAnchor.constraint(equalTo: emailButton.centerXAnchor),
        ])
    }
}